# Big Bertha's Masters Pool 2026

A fully functional Masters Tournament pool website. Participants pick players from 5 tiers, and the pool ranks everyone by total prize money earned.

## Quick Start

```bash
npm install
npm run dev
```

Opens at `http://localhost:5173`

## Deploy to Vercel

1. Push this repo to GitHub
2. Go to [vercel.com](https://vercel.com) and sign in with GitHub
3. Click "New Project" → import this repo
4. Click "Deploy" — no config needed, Vite is auto-detected
5. You'll get a live URL like `big-bertha-masters-pool.vercel.app`

## Admin Access

- Navigate to the Admin tab
- Default password: `bigbertha2026`
- **Change this** in `src/App.jsx` (search for `ADMIN_PASSWORD`) before sharing

## How It Works

- **Picks**: Participants select 1 player from each of 5 tiers
- **Scoring**: Total prize money earned by all 5 players
- **Live Scores**: Pulls from ESPN's public golf API during the tournament (auto-refreshes every 2 minutes)
- **Storage**: Uses browser localStorage — all data persists in each visitor's browser

## Important: Storage Note

This app uses `localStorage` which means:
- Entries are stored in the **admin's browser** — if you clear browser data, entries are lost
- Each visitor sees their own localStorage, not a shared database

For a shared pool with many participants, you'll want a backend database. Options:
- **Firebase Firestore** (free tier) — easiest to add
- **Supabase** (free tier) — Postgres-based
- **JSON file on a server** — simplest

For a small pool (under ~30 people), you can manage it by:
1. Having everyone submit picks on the site
2. You (admin) manually track entries in the admin portal
3. Or have people text/email you their picks and you enter them via the admin "Add Picks" tab

## Customization

- **Tiers**: Edit the `TIERS` object at the top of `src/App.jsx`
- **E-transfer email**: Change `ETRANSFER_EMAIL`
- **Buy-in amount**: Change `BUY_IN`
- **Admin password**: Change `ADMIN_PASSWORD`
- **Payout structure**: Currently 60/30/10 — edit in the HomePage and RulesPage components

## Tech Stack

- React 18
- Vite
- No dependencies beyond React — pure CSS styling
- ESPN public API for live scores
