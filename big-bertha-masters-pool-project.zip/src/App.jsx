import { useState, useEffect, useCallback, useRef } from "react";

// ============================================================
// BIG BERTHA'S MASTERS POOL 2026
// ============================================================

// --- TIERS based on current odds (as of March 30, 2026) ---
const TIERS = {
  1: {
    label: "Tier 1",
    players: [
      "Scottie Scheffler", "Rory McIlroy", "Bryson DeChambeau",
      "Jon Rahm", "Ludvig Åberg", "Xander Schauffele"
    ]
  },
  2: {
    label: "Tier 2",
    players: [
      "Collin Morikawa", "Tommy Fleetwood", "Matt Fitzpatrick",
      "Cameron Young", "Hideki Matsuyama", "Brooks Koepka",
      "Patrick Reed", "Viktor Hovland"
    ]
  },
  3: {
    label: "Tier 3",
    players: [
      "Sam Burns", "Im Sung-jae", "Patrick Cantlay",
      "Robert MacIntyre", "Jordan Spieth", "Corey Conners",
      "Keegan Bradley", "Justin Thomas", "Shane Lowry", "Justin Rose"
    ]
  },
  4: {
    label: "Tier 4",
    players: [
      "Jason Day", "Tyrrell Hatton", "Max Homa", "Sepp Straka",
      "Harris English", "Akshay Bhatia", "Russell Henley", "Ryan Fox",
      "Chris Gotterup", "Cameron Smith", "Dustin Johnson", "Min Woo Lee"
    ]
  },
  5: {
    label: "Tier 5",
    players: [
      "Tony Finau", "Andrew Novak", "Wyndham Clark", "Brian Harman",
      "Tom Kim", "Adam Scott", "Sergio Garcia", "Nick Taylor",
      "Maverick McNealy", "Ben Griffin", "Harry Hall",
      "Daniel Berger", "Aaron Rai", "Phil Mickelson",
      "Kurt Kitayama", "Jacob Bridgeman", "Brian Campbell",
      "Nico Echavarría", "Aldrich Potgieter", "Marco Penge",
      "Li Haotong", "Carlos Ortiz", "J.J. Spaun",
      "Bubba Watson", "Tiger Woods", "Danny Willett",
      "Charl Schwartzel", "Mike Weir", "Fred Couples",
      "Vijay Singh", "Ángel Cabrera", "Adam Scott",
      "Jackson Herrington (a)", "Mason Howell (a)", "Ethan Fang (a)",
      "Fifa Laopakdee (a)", "Mateo Pulcini (a)", "Brandon Holtz (a)",
      "Anyone else not listed"
    ]
  }
};

// Prize money data from 2025 Masters (purse was $20M; 2026 is $21M)
// We'll scale these up proportionally. During the tournament, live data replaces this.
const SAMPLE_PRIZE_MONEY = {
  1: 3600000, 2: 2160000, 3: 1360000, 4: 960000, 5: 800000,
  6: 720000, 7: 670000, 8: 620000, 9: 580000, 10: 540000,
  11: 500000, 12: 460000, 13: 420000, 14: 380000, 15: 340000,
  16: 300000, 17: 280000, 18: 260000, 19: 240000, 20: 220000,
  21: 200000, 22: 186000, 23: 172000, 24: 158000, 25: 148000,
  26: 138000, 27: 128000, 28: 118000, 29: 108000, 30: 98000,
  31: 93000, 32: 88000, 33: 83000, 34: 79000, 35: 75000,
  36: 71000, 37: 67000, 38: 64000, 39: 61000, 40: 58000,
  41: 55000, 42: 52000, 43: 49000, 44: 46000, 45: 43000,
  46: 40800, 47: 38600, 48: 36800, 49: 35200, 50: 34000,
};

// E-transfer info
const ETRANSFER_EMAIL = "csharpe6@uwo.ca";
const BUY_IN = 20;

// Admin password (in production, use env vars / proper auth)
const ADMIN_PASSWORD = "bigbertha2026";

// Storage keys
const STORAGE_KEYS = {
  ENTRIES: "masters-pool-entries",
  SCORES: "masters-pool-scores",
  CONFIG: "masters-pool-config",
  PARTICIPANTS: "masters-pool-participants"
};

// ============================================================
// UTILITY FUNCTIONS
// ============================================================
const formatMoney = (amount) => {
  if (amount === 0 || amount === null || amount === undefined) return "$0";
  return "$" + Number(amount).toLocaleString("en-US");
};

const generateId = () => Math.random().toString(36).substring(2, 10) + Date.now().toString(36);

// ============================================================
// STORAGE LAYER (uses artifact persistent storage)
// ============================================================
const storage = {
  async get(key) {
    try {
      const val = localStorage.getItem(key);
      return val ? JSON.parse(val) : null;
    } catch { return null; }
  },
  async set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch { return false; }
  },
  async delete(key) {
    try {
      localStorage.removeItem(key);
      return true;
    } catch { return false; }
  }
};

// ============================================================
// ESPN API LAYER — Live scoring during tournament
// ============================================================
const ESPN_GOLF_URL = "https://site.api.espn.com/apis/site/v2/sports/golf/pga/scoreboard";

async function fetchLiveScores() {
  try {
    const res = await fetch(ESPN_GOLF_URL);
    if (!res.ok) return null;
    const data = await res.json();
    // Find the Masters event
    const mastersEvent = data?.events?.find(e =>
      e.name?.toLowerCase().includes("masters") ||
      e.shortName?.toLowerCase().includes("masters")
    );
    if (!mastersEvent) return null;

    const competition = mastersEvent.competitions?.[0];
    if (!competition) return null;

    const players = {};
    for (const competitor of (competition.competitors || [])) {
      const name = competitor.athlete?.displayName || competitor.athlete?.shortName;
      if (!name) continue;
      const earnings = competitor.earnings ? parseFloat(competitor.earnings) : 0;
      const position = competitor.status?.position?.id || competitor.sortOrder || 999;
      const score = competitor.score || competitor.linescores?.reduce((a, l) => a + (l.value || 0), 0) || 0;
      const status = competitor.status?.type?.description || "active";
      players[name] = {
        position: parseInt(position),
        score,
        earnings,
        status,
        thru: competitor.status?.thru || "",
        today: competitor.linescores?.slice(-1)?.[0]?.value || "",
        rounds: (competitor.linescores || []).map(l => l.value)
      };
    }
    return {
      status: mastersEvent.status?.type?.description || "pre",
      round: competition.status?.period || 0,
      players,
      lastUpdated: new Date().toISOString()
    };
  } catch (e) {
    console.error("ESPN fetch error:", e);
    return null;
  }
}

// ============================================================
// MAIN APP COMPONENT
// ============================================================
export default function MastersPool() {
  const [page, setPage] = useState("home"); // home, pick, leaderboard, scores, admin, rules
  const [entries, setEntries] = useState([]);
  const [participants, setParticipants] = useState([]); // {id, name, invited: bool, paid: bool}
  const [liveScores, setLiveScores] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [tournamentStatus, setTournamentStatus] = useState("pre"); // pre, in, post
  const [picksLocked, setPicksLocked] = useState(false);
  const scoreInterval = useRef(null);

  // Load data on mount
  useEffect(() => {
    async function init() {
      setLoading(true);
      const savedEntries = await storage.get(STORAGE_KEYS.ENTRIES);
      if (savedEntries) setEntries(savedEntries);

      const savedParticipants = await storage.get(STORAGE_KEYS.PARTICIPANTS);
      if (savedParticipants) setParticipants(savedParticipants);

      const savedScores = await storage.get(STORAGE_KEYS.SCORES);
      if (savedScores) setLiveScores(savedScores);

      const config = await storage.get(STORAGE_KEYS.CONFIG);
      if (config?.picksLocked) setPicksLocked(true);

      // Try fetching live scores
      const live = await fetchLiveScores();
      if (live) {
        setLiveScores(live);
        setTournamentStatus(live.status === "in" ? "in" : live.status === "post" ? "post" : "pre");
        await storage.set(STORAGE_KEYS.SCORES, live);
      }
      setLoading(false);
    }
    init();
  }, []);

  // Periodic score refresh during tournament
  useEffect(() => {
    if (tournamentStatus === "in") {
      scoreInterval.current = setInterval(async () => {
        const live = await fetchLiveScores();
        if (live) {
          setLiveScores(live);
          await storage.set(STORAGE_KEYS.SCORES, live);
        }
      }, 120000); // every 2 minutes
    }
    return () => { if (scoreInterval.current) clearInterval(scoreInterval.current); };
  }, [tournamentStatus]);

  // Save entries whenever they change
  const saveEntries = useCallback(async (newEntries) => {
    setEntries(newEntries);
    await storage.set(STORAGE_KEYS.ENTRIES, newEntries);
  }, []);

  // Save participants whenever they change
  const saveParticipants = useCallback(async (newParticipants) => {
    setParticipants(newParticipants);
    await storage.set(STORAGE_KEYS.PARTICIPANTS, newParticipants);
  }, []);

  // Calculate pool standings
  const getStandings = useCallback(() => {
    if (!liveScores?.players || entries.length === 0) return [];

    return entries.map(entry => {
      let totalEarnings = 0;
      const playerDetails = entry.picks.map(pick => {
        // Try exact match first, then fuzzy
        let playerData = liveScores.players[pick];
        if (!playerData) {
          const key = Object.keys(liveScores.players).find(k =>
            k.toLowerCase().includes(pick.toLowerCase().split(" ").pop())
          );
          if (key) playerData = liveScores.players[key];
        }
        const earnings = playerData?.earnings || 0;
        totalEarnings += earnings;
        return {
          name: pick,
          position: playerData?.position || "-",
          earnings,
          score: playerData?.score || "-",
          status: playerData?.status || "unknown",
          thru: playerData?.thru || ""
        };
      });
      return {
        ...entry,
        totalEarnings,
        playerDetails
      };
    }).sort((a, b) => b.totalEarnings - a.totalEarnings);
  }, [entries, liveScores]);

  if (loading) return <LoadingScreen />;

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(175deg, #0a3d0a 0%, #064006 40%, #032003 100%)",
      fontFamily: "'Georgia', 'Times New Roman', serif",
      color: "#f5f0e1",
      position: "relative",
      overflow: "hidden"
    }}>
      {/* Subtle depth texture */}
      <div style={{
        position: "fixed", inset: 0, pointerEvents: "none", zIndex: 0,
        background: "radial-gradient(ellipse at 50% 0%, rgba(20,80,20,0.15) 0%, transparent 60%), radial-gradient(ellipse at 80% 70%, rgba(10,50,10,0.1) 0%, transparent 50%), radial-gradient(ellipse at 20% 90%, rgba(10,50,10,0.08) 0%, transparent 40%)",
      }} />

      <Nav page={page} setPage={setPage} isAdmin={isAdmin} />

      <div style={{ position: "relative", zIndex: 1 }}>
        {page === "home" && <HomePage setPage={setPage} entries={entries} />}
        {page === "pick" && (
          <PickPage
            entries={entries}
            saveEntries={saveEntries}
            picksLocked={picksLocked}
            setPage={setPage}
          />
        )}
        {page === "leaderboard" && (
          <LeaderboardPage
            standings={getStandings()}
            liveScores={liveScores}
            entries={entries}
          />
        )}
        {page === "scores" && <ScoresPage liveScores={liveScores} />}
        {page === "rules" && <RulesPage />}
        {page === "admin" && (
          <AdminPage
            isAdmin={isAdmin}
            setIsAdmin={setIsAdmin}
            entries={entries}
            saveEntries={saveEntries}
            picksLocked={picksLocked}
            setPicksLocked={(v) => {
              setPicksLocked(v);
              storage.set(STORAGE_KEYS.CONFIG, { picksLocked: v });
            }}
            liveScores={liveScores}
            setLiveScores={setLiveScores}
            participants={participants}
            saveParticipants={saveParticipants}
          />
        )}
      </div>
    </div>
  );
}

// ============================================================
// LOADING SCREEN
// ============================================================
function LoadingScreen() {
  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(175deg, #0a3d0a 0%, #064006 40%, #032003 100%)",
      display: "flex", alignItems: "center", justifyContent: "center",
      flexDirection: "column", gap: 16,
      fontFamily: "'Georgia', serif", color: "#f5f0e1"
    }}>
      <div style={{ fontSize: 48, letterSpacing: 4, fontWeight: 700, color: "#d4af37" }}></div>
      <div style={{ fontSize: 18, letterSpacing: 6, textTransform: "uppercase", opacity: 0.7 }}>
        Loading the Pool...
      </div>
    </div>
  );
}

// ============================================================
// NAVIGATION
// ============================================================
function Nav({ page, setPage, isAdmin }) {
  const links = [
    { id: "home", label: "Home" },
    { id: "pick", label: "Make Picks" },
    { id: "leaderboard", label: "Our Leaderboard" },
    { id: "scores", label: "Live Scores" },
    { id: "rules", label: "Rules" },
    { id: "admin", label: isAdmin ? "Admin" : "Admin" },
  ];
  return (
    <nav style={{
      position: "sticky", top: 0, zIndex: 100,
      background: "linear-gradient(180deg, rgba(6,30,6,0.98) 0%, rgba(6,30,6,0.92) 100%)",
      backdropFilter: "blur(12px)",
      borderBottom: "1px solid rgba(212,175,55,0.25)",
      padding: "0 16px",
    }}>
      <div style={{
        maxWidth: 1100, margin: "0 auto",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        flexWrap: "wrap", gap: 4
      }}>
        <div
          onClick={() => setPage("home")}
          style={{
            cursor: "pointer", padding: "12px 0",
            fontWeight: 700, fontSize: 15, letterSpacing: 3,
            textTransform: "uppercase", color: "#d4af37",
            whiteSpace: "nowrap"
          }}
        >
          Big Bertha's Pool
        </div>
        <div style={{ display: "flex", gap: 2, flexWrap: "wrap" }}>
          {links.map(l => (
            <button
              key={l.id}
              onClick={() => setPage(l.id)}
              style={{
                background: page === l.id ? "rgba(212,175,55,0.15)" : "transparent",
                border: "none",
                color: page === l.id ? "#d4af37" : "rgba(245,240,225,0.6)",
                padding: "12px 14px",
                fontSize: 12.5,
                fontFamily: "'Georgia', serif",
                letterSpacing: 1.5,
                textTransform: "uppercase",
                cursor: "pointer",
                borderBottom: page === l.id ? "2px solid #d4af37" : "2px solid transparent",
                transition: "all 0.2s",
                whiteSpace: "nowrap"
              }}
            >
              {l.label}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}

// ============================================================
// HOME PAGE
// ============================================================
function HomePage({ setPage, entries }) {
  return (
    <div style={{ maxWidth: 800, margin: "0 auto", padding: "40px 20px", textAlign: "center" }}>
      {/* Hero */}
      <div style={{ marginBottom: 48 }}>
        <div style={{
          fontSize: 13, letterSpacing: 8, textTransform: "uppercase",
          color: "rgba(212,175,55,0.6)", marginBottom: 12
        }}>
          THE 90TH MASTERS TOURNAMENT
        </div>
        <h1 style={{
          fontSize: "clamp(36px, 8vw, 64px)",
          fontWeight: 700,
          color: "#d4af37",
          margin: "0 0 8px 0",
          lineHeight: 1.05,
          letterSpacing: 2
        }}>
          Big Bertha's<br />Masters Pool
        </h1>

        {/* Elegant divider */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 16, margin: "16px 0 12px 0" }}>
          <div style={{ width: 60, height: 1, background: "linear-gradient(90deg, transparent, rgba(212,175,55,0.5))" }} />
          <div style={{ width: 6, height: 6, borderRadius: "50%", background: "rgba(212,175,55,0.4)" }} />
          <div style={{ width: 60, height: 1, background: "linear-gradient(270deg, transparent, rgba(212,175,55,0.5))" }} />
        </div>

        <div style={{
          fontSize: "clamp(14px, 3vw, 18px)",
          color: "rgba(245,240,225,0.5)",
          letterSpacing: 3, textTransform: "uppercase"
        }}>
          2026 Edition
        </div>
      </div>

      {/* Date card */}
      <div style={{
        background: "rgba(212,175,55,0.08)",
        border: "1px solid rgba(212,175,55,0.2)",
        borderRadius: 8,
        padding: "24px 32px",
        display: "inline-block",
        marginBottom: 40
      }}>
        <div style={{ fontSize: 14, letterSpacing: 4, textTransform: "uppercase", color: "#d4af37", marginBottom: 4 }}>
          Augusta National Golf Club
        </div>
        <div style={{ fontSize: 24, fontWeight: 700 }}>April 9–12, 2026</div>
        <div style={{ fontSize: 13, color: "rgba(245,240,225,0.5)", marginTop: 6 }}>
          Picks lock before Round 1 tee-off • Thursday, April 9th
        </div>
      </div>

      {/* Stats row */}
      <div style={{
        display: "flex", justifyContent: "center", gap: 32,
        flexWrap: "wrap", marginBottom: 48
      }}>
        {[
          { val: entries.length, label: "Entries" },
          { val: "$20", label: "Buy-In" },
          { val: formatMoney(entries.length * 20), label: "Prize Pool" },
        ].map((s, i) => (
          <div key={i} style={{ textAlign: "center" }}>
            <div style={{ fontSize: 32, fontWeight: 700, color: "#d4af37" }}>{s.val}</div>
            <div style={{ fontSize: 11, letterSpacing: 3, textTransform: "uppercase", color: "rgba(245,240,225,0.4)" }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Payout structure */}
      <div style={{
        background: "rgba(0,0,0,0.2)",
        border: "1px solid rgba(212,175,55,0.15)",
        borderRadius: 8,
        padding: 24,
        marginBottom: 40,
        maxWidth: 500,
        margin: "0 auto 40px auto"
      }}>
        <div style={{ fontSize: 12, letterSpacing: 4, textTransform: "uppercase", color: "#d4af37", marginBottom: 16 }}>
          Payout Structure
        </div>
        <div style={{ display: "flex", justifyContent: "center", gap: 32 }}>
          {[
            { place: "1st", pct: "60%", amt: formatMoney(Math.round(entries.length * 20 * 0.6)) },
            { place: "2nd", pct: "30%", amt: formatMoney(Math.round(entries.length * 20 * 0.3)) },
            { place: "3rd", pct: "10%", amt: formatMoney(Math.round(entries.length * 20 * 0.1)) },
          ].map((p, i) => (
            <div key={i} style={{ textAlign: "center" }}>
              <div style={{ fontSize: 20, fontWeight: 700 }}>{p.place}</div>
              <div style={{ fontSize: 14, color: "#d4af37" }}>{p.pct}</div>
              <div style={{ fontSize: 12, color: "rgba(245,240,225,0.4)" }}>{p.amt}</div>
            </div>
          ))}
        </div>
      </div>

      {/* E-Transfer Info */}
      <div style={{
        background: "rgba(0,0,0,0.25)",
        border: "1px solid rgba(212,175,55,0.2)",
        borderRadius: 8,
        padding: 24,
        marginBottom: 40,
        maxWidth: 500,
        margin: "0 auto 40px auto"
      }}>
        <div style={{ fontSize: 12, letterSpacing: 4, textTransform: "uppercase", color: "#d4af37", marginBottom: 12 }}>
          How to Pay
        </div>
        <div style={{ fontSize: 15, marginBottom: 8 }}>
          Send <strong style={{ color: "#d4af37" }}>${BUY_IN}</strong> via e-transfer to:
        </div>
        <div style={{
          background: "rgba(212,175,55,0.1)",
          border: "1px solid rgba(212,175,55,0.3)",
          borderRadius: 6,
          padding: "12px 20px",
          fontSize: 18,
          fontWeight: 700,
          color: "#d4af37",
          letterSpacing: 1,
          display: "inline-block",
          cursor: "pointer",
          userSelect: "all"
        }}
          onClick={() => { try { navigator.clipboard.writeText(ETRANSFER_EMAIL); } catch {} }}
          title="Click to copy"
        >
          {ETRANSFER_EMAIL}
        </div>
        <div style={{ fontSize: 12, color: "rgba(245,240,225,0.35)", marginTop: 8 }}>
          Click to copy • Please confirm payment before tee-off
        </div>
      </div>

      {/* CTA */}
      <button
        onClick={() => setPage("pick")}
        style={{
          background: "linear-gradient(135deg, #d4af37 0%, #b8941f 100%)",
          color: "#0a2e0a",
          border: "none",
          borderRadius: 6,
          padding: "16px 48px",
          fontSize: 16,
          fontWeight: 700,
          letterSpacing: 3,
          textTransform: "uppercase",
          cursor: "pointer",
          fontFamily: "'Georgia', serif",
          boxShadow: "0 4px 24px rgba(212,175,55,0.3)",
          transition: "transform 0.15s, box-shadow 0.15s",
        }}
        onMouseOver={e => { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 6px 32px rgba(212,175,55,0.4)"; }}
        onMouseOut={e => { e.currentTarget.style.transform = "none"; e.currentTarget.style.boxShadow = "0 4px 24px rgba(212,175,55,0.3)"; }}
      >
        Submit Your Picks
      </button>

      <div style={{ marginTop: 16, fontSize: 13, color: "rgba(245,240,225,0.35)" }}>
        Don't forget your ${BUY_IN} e-transfer!
      </div>
    </div>
  );
}

// ============================================================
// PICK PAGE
// ============================================================
function PickPage({ entries, saveEntries, picksLocked, setPage }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [picks, setPicks] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");
  const [customPlayer, setCustomPlayer] = useState("");
  const [showCustom, setShowCustom] = useState(false);

  const handlePick = (tier, player) => {
    setPicks(prev => ({ ...prev, [tier]: player }));
  };

  const handleSubmit = async () => {
    setError("");
    if (!name.trim()) { setError("Please enter your name."); return; }
    if (Object.keys(picks).length < 5) { setError("Please pick one player from each tier."); return; }
    for (let t = 1; t <= 5; t++) {
      if (!picks[t]) { setError(`Please pick a player from Tier ${t}.`); return; }
    }

    // Check for duplicate entries by name
    const existingEntry = entries.find(e => e.name.toLowerCase().trim() === name.toLowerCase().trim());
    if (existingEntry) { setError("An entry with this name already exists. Contact the admin to update your picks."); return; }

    const entry = {
      id: generateId(),
      name: name.trim(),
      email: email.trim(),
      picks: [picks[1], picks[2], picks[3], picks[4], picks[5]],
      tierPicks: { ...picks },
      submittedAt: new Date().toISOString(),
      submittedBy: "self"
    };

    const newEntries = [...entries, entry];
    await saveEntries(newEntries);
    setSubmitted(true);
  };

  if (picksLocked) {
    return (
      <div style={{ maxWidth: 700, margin: "0 auto", padding: "60px 20px", textAlign: "center" }}>
        
        <h2 style={{ color: "#d4af37", fontSize: 28, marginBottom: 12 }}>Picks Are Locked</h2>
        <p style={{ color: "rgba(245,240,225,0.6)", fontSize: 16 }}>
          The tournament has begun or picks have been locked by the admin.
          <br />Check the leaderboard to see how everyone is doing!
        </p>
        <button
          onClick={() => setPage("leaderboard")}
          style={goldBtnStyle}
        >
          View Our Leaderboard
        </button>
      </div>
    );
  }

  if (submitted) {
    return (
      <div style={{ maxWidth: 700, margin: "0 auto", padding: "60px 20px", textAlign: "center" }}>
        
        <h2 style={{ color: "#d4af37", fontSize: 28, marginBottom: 12 }}>Picks Submitted!</h2>
        <p style={{ color: "rgba(245,240,225,0.6)", fontSize: 16, marginBottom: 8 }}>
          Good luck, <strong>{name}</strong>! Your team:
        </p>
        <div style={{
          background: "rgba(0,0,0,0.3)", borderRadius: 8,
          padding: 20, maxWidth: 400, margin: "16px auto 32px auto",
          border: "1px solid rgba(212,175,55,0.2)"
        }}>
          {[1,2,3,4,5].map(t => (
            <div key={t} style={{
              display: "flex", justifyContent: "space-between",
              padding: "8px 0",
              borderBottom: t < 5 ? "1px solid rgba(255,255,255,0.05)" : "none"
            }}>
              <span style={{ color: "rgba(245,240,225,0.4)", fontSize: 12 }}>Tier {t}</span>
              <span style={{ fontWeight: 600 }}>{picks[t]}</span>
            </div>
          ))}
        </div>
        <p style={{ color: "rgba(245,240,225,0.4)", fontSize: 13 }}>
          Don't forget to send your $20 buy-in via e-transfer before tee-off!
        </p>
        <button onClick={() => setPage("home")} style={goldBtnStyle}>
          Back to Home
        </button>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 800, margin: "0 auto", padding: "32px 16px" }}>
      <div style={{ textAlign: "center", marginBottom: 32 }}>
        <h2 style={{ color: "#d4af37", fontSize: 28, margin: "0 0 8px 0" }}>
          Make Your Picks
        </h2>
        <p style={{ color: "rgba(245,240,225,0.5)", fontSize: 14, margin: 0 }}>
          Pick one player from each of the 5 tiers. All 5 players' prize money counts toward your total.
        </p>
      </div>

      {/* Name/Email */}
      <div style={{
        background: "rgba(0,0,0,0.25)", borderRadius: 8,
        padding: 20, marginBottom: 24,
        border: "1px solid rgba(212,175,55,0.15)"
      }}>
        <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
          <div style={{ flex: "1 1 200px" }}>
            <label style={labelStyle}>Your Name *</label>
            <input
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Enter your name"
              style={inputStyle}
            />
          </div>
          <div style={{ flex: "1 1 200px" }}>
            <label style={labelStyle}>Email (optional)</label>
            <input
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@email.com"
              style={inputStyle}
            />
          </div>
        </div>
      </div>

      {/* Tier Picks */}
      {[1, 2, 3, 4, 5].map(tier => (
        <div key={tier} style={{
          background: "rgba(0,0,0,0.2)",
          border: picks[tier] ? "1px solid rgba(212,175,55,0.4)" : "1px solid rgba(255,255,255,0.06)",
          borderRadius: 8,
          padding: 20,
          marginBottom: 16,
          transition: "border-color 0.3s"
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 12, flexWrap: "wrap", gap: 8 }}>
            <div>
              <div style={{ fontSize: 16, fontWeight: 700, color: "#d4af37" }}>
                {TIERS[tier].label}
              </div>
            </div>
            {picks[tier] && (
              <div style={{
                background: "rgba(212,175,55,0.15)",
                color: "#d4af37",
                padding: "4px 12px",
                borderRadius: 20,
                fontSize: 12,
                fontWeight: 600
              }}>
                ✓ {picks[tier]}
              </div>
            )}
          </div>

          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {TIERS[tier].players.map(player => {
              if (player === "Anyone else not listed") {
                return (
                  <div key={player} style={{ width: "100%", marginTop: 8 }}>
                    {!showCustom ? (
                      <button
                        onClick={() => setShowCustom(true)}
                        style={{
                          ...playerBtnStyle,
                          background: "rgba(212,175,55,0.05)",
                          borderStyle: "dashed",
                          width: "auto",
                          fontSize: 12
                        }}
                      >
                        + Pick someone else not listed
                      </button>
                    ) : (
                      <div style={{ display: "flex", gap: 8 }}>
                        <input
                          value={customPlayer}
                          onChange={e => setCustomPlayer(e.target.value)}
                          placeholder="Type player name..."
                          style={{ ...inputStyle, flex: 1, marginBottom: 0 }}
                        />
                        <button
                          onClick={() => {
                            if (customPlayer.trim()) {
                              handlePick(tier, customPlayer.trim());
                              setShowCustom(false);
                              setCustomPlayer("");
                            }
                          }}
                          style={{ ...goldBtnStyle, padding: "8px 16px", fontSize: 12 }}
                        >
                          Select
                        </button>
                      </div>
                    )}
                  </div>
                );
              }
              const isSelected = picks[tier] === player;
              return (
                <button
                  key={player}
                  onClick={() => handlePick(tier, player)}
                  style={{
                    ...playerBtnStyle,
                    background: isSelected ? "rgba(212,175,55,0.2)" : "rgba(255,255,255,0.04)",
                    borderColor: isSelected ? "#d4af37" : "rgba(255,255,255,0.08)",
                    color: isSelected ? "#d4af37" : "#f5f0e1",
                    fontWeight: isSelected ? 700 : 400,
                  }}
                >
                  {player}
                </button>
              );
            })}
          </div>
        </div>
      ))}

      {/* Error */}
      {error && (
        <div style={{
          background: "rgba(200,50,50,0.15)",
          border: "1px solid rgba(200,50,50,0.4)",
          borderRadius: 6, padding: "12px 16px",
          color: "#ff9999", fontSize: 14, marginBottom: 16, textAlign: "center"
        }}>
          {error}
        </div>
      )}

      {/* Summary & Submit */}
      <div style={{
        background: "rgba(0,0,0,0.3)",
        border: "1px solid rgba(212,175,55,0.2)",
        borderRadius: 8, padding: 24, textAlign: "center"
      }}>
        <div style={{ fontSize: 12, letterSpacing: 3, textTransform: "uppercase", color: "#d4af37", marginBottom: 12 }}>
          Your Team ({Object.keys(picks).length}/5 selected)
        </div>
        <div style={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: 8, marginBottom: 20 }}>
          {[1,2,3,4,5].map(t => (
            <div key={t} style={{
              background: picks[t] ? "rgba(212,175,55,0.12)" : "rgba(255,255,255,0.03)",
              border: `1px solid ${picks[t] ? "rgba(212,175,55,0.3)" : "rgba(255,255,255,0.06)"}`,
              borderRadius: 6, padding: "6px 12px", fontSize: 13,
              color: picks[t] ? "#f5f0e1" : "rgba(245,240,225,0.25)"
            }}>
              {picks[t] || `Tier ${t}`}
            </div>
          ))}
        </div>
        <button
          onClick={handleSubmit}
          disabled={Object.keys(picks).length < 5 || !name.trim()}
          style={{
            ...goldBtnStyle,
            opacity: (Object.keys(picks).length < 5 || !name.trim()) ? 0.4 : 1,
            cursor: (Object.keys(picks).length < 5 || !name.trim()) ? "not-allowed" : "pointer"
          }}
        >
          Submit Picks
        </button>

        {/* E-transfer reminder */}
        <div style={{
          marginTop: 16,
          background: "rgba(212,175,55,0.06)",
          border: "1px solid rgba(212,175,55,0.2)",
          borderRadius: 6,
          padding: "12px 16px",
          fontSize: 13,
          color: "rgba(245,240,225,0.6)"
        }}>
          <strong>Reminder:</strong> Send your <strong style={{ color: "#d4af37" }}>${BUY_IN} e-transfer</strong> to{" "}
          <span
            style={{ color: "#d4af37", fontWeight: 700, cursor: "pointer", textDecoration: "underline", textDecorationStyle: "dotted" }}
            onClick={() => { try { navigator.clipboard.writeText(ETRANSFER_EMAIL); } catch {} }}
            title="Click to copy"
          >
            {ETRANSFER_EMAIL}
          </span>
          {" "}before first tee-off on Thursday, April 9th.
        </div>
      </div>
    </div>
  );
}

// ============================================================
// LEADERBOARD PAGE
// ============================================================
function LeaderboardPage({ standings, liveScores, entries }) {
  const hasLiveData = liveScores?.players && Object.keys(liveScores.players).length > 0;

  if (entries.length === 0) {
    return (
      <div style={{ maxWidth: 800, margin: "0 auto", padding: "60px 20px", textAlign: "center" }}>
        <h2 style={{ color: "#d4af37", fontSize: 28 }}>Our Pool Leaderboard</h2>
        <p style={{ color: "rgba(245,240,225,0.5)" }}>No entries yet. Be the first to submit your picks!</p>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 1000, margin: "0 auto", padding: "32px 16px" }}>
      <div style={{ textAlign: "center", marginBottom: 24 }}>
        <h2 style={{ color: "#d4af37", fontSize: 28, margin: "0 0 8px 0" }}>Our Pool Leaderboard</h2>
        {liveScores?.lastUpdated && (
          <div style={{ fontSize: 12, color: "rgba(245,240,225,0.35)" }}>
            Last updated: {new Date(liveScores.lastUpdated).toLocaleString()}
          </div>
        )}
        {!hasLiveData && (
          <div style={{
            background: "rgba(212,175,55,0.08)", border: "1px solid rgba(212,175,55,0.2)",
            borderRadius: 6, padding: "10px 16px", display: "inline-block", marginTop: 12,
            fontSize: 13, color: "rgba(245,240,225,0.6)"
          }}>
            Live scores will appear once the tournament begins on April 9th.
            <br />Standings below show all entries and their picks.
          </div>
        )}
      </div>

      {/* Standings Table */}
      <div style={{
        background: "rgba(0,0,0,0.25)",
        border: "1px solid rgba(212,175,55,0.15)",
        borderRadius: 8,
        overflow: "hidden"
      }}>
        {/* Header */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "48px 1fr 120px",
          padding: "12px 16px",
          background: "rgba(212,175,55,0.08)",
          borderBottom: "1px solid rgba(212,175,55,0.15)",
          fontSize: 11, letterSpacing: 2, textTransform: "uppercase",
          color: "rgba(245,240,225,0.5)"
        }}>
          <div>#</div>
          <div>Name</div>
          <div style={{ textAlign: "right" }}>Total Earnings</div>
        </div>

        {/* Rows */}
        {(hasLiveData ? standings : entries.map((e, i) => ({ ...e, totalEarnings: 0, playerDetails: e.picks.map(p => ({ name: p })) }))).map((entry, i) => (
          <EntryRow key={entry.id} entry={entry} rank={i + 1} hasLiveData={hasLiveData} />
        ))}
      </div>
    </div>
  );
}

function EntryRow({ entry, rank, hasLiveData }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div style={{
      borderBottom: "1px solid rgba(255,255,255,0.04)",
      background: rank <= 3 && hasLiveData ? `rgba(212,175,55,${0.06 - rank * 0.015})` : "transparent"
    }}>
      <div
        onClick={() => setExpanded(!expanded)}
        style={{
          display: "grid",
          gridTemplateColumns: "48px 1fr 120px",
          padding: "14px 16px",
          cursor: "pointer",
          transition: "background 0.15s",
          alignItems: "center"
        }}
        onMouseOver={e => e.currentTarget.style.background = "rgba(255,255,255,0.03)"}
        onMouseOut={e => e.currentTarget.style.background = "transparent"}
      >
        <div style={{
          fontWeight: 700, fontSize: 16,
          color: rank === 1 ? "#d4af37" : rank === 2 ? "#c0c0c0" : rank === 3 ? "#cd7f32" : "rgba(245,240,225,0.4)"
        }}>
          {rank}
        </div>
        <div>
          <div style={{ fontWeight: 600, fontSize: 15 }}>{entry.name}</div>
          <div style={{ fontSize: 11, color: "rgba(245,240,225,0.35)", marginTop: 2 }}>
            {entry.picks?.join(" • ") || ""}
          </div>
        </div>
        <div style={{ textAlign: "right", fontWeight: 700, fontSize: 16, color: hasLiveData ? "#d4af37" : "rgba(245,240,225,0.3)" }}>
          {hasLiveData ? formatMoney(entry.totalEarnings) : "—"}
        </div>
      </div>

      {/* Expanded player details */}
      {expanded && (
        <div style={{
          padding: "0 16px 16px 64px",
          display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 8
        }}>
          {(entry.playerDetails || entry.picks?.map(p => ({ name: p })) || []).map((p, j) => (
            <div key={j} style={{
              background: "rgba(0,0,0,0.2)", borderRadius: 6,
              padding: "8px 12px",
              border: "1px solid rgba(255,255,255,0.04)"
            }}>
              <div style={{ fontSize: 13, fontWeight: 600 }}>{p.name}</div>
              {hasLiveData && (
                <div style={{ fontSize: 11, color: "rgba(245,240,225,0.4)", marginTop: 4 }}>
                  {p.status === "cut" ? "Missed Cut" : `Pos: ${p.position}`}
                  {" • "}{p.thru || ""}
                  {" • "}<span style={{ color: "#d4af37" }}>{formatMoney(p.earnings)}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ============================================================
// LIVE SCORES PAGE
// ============================================================
function ScoresPage({ liveScores }) {
  const hasData = liveScores?.players && Object.keys(liveScores.players).length > 0;

  if (!hasData) {
    return (
      <div style={{ maxWidth: 800, margin: "0 auto", padding: "60px 20px", textAlign: "center" }}>
        <h2 style={{ color: "#d4af37", fontSize: 28, marginBottom: 12 }}>Live Tournament Scores</h2>
        <div style={{
          background: "rgba(0,0,0,0.25)", border: "1px solid rgba(212,175,55,0.15)",
          borderRadius: 8, padding: 32
        }}>
          <div style={{ fontSize: 36, marginBottom: 12 }}></div>
          <p style={{ color: "rgba(245,240,225,0.5)", fontSize: 16, margin: "0 0 8px 0" }}>
            Tournament hasn't started yet
          </p>
          <p style={{ color: "rgba(245,240,225,0.35)", fontSize: 14, margin: 0 }}>
            Live scores will appear here starting Thursday, April 9th.
            <br />Scores refresh automatically every 2 minutes during play.
          </p>
        </div>
      </div>
    );
  }

  const sortedPlayers = Object.entries(liveScores.players)
    .sort((a, b) => (a[1].position || 999) - (b[1].position || 999));

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "32px 16px" }}>
      <div style={{ textAlign: "center", marginBottom: 24 }}>
        <h2 style={{ color: "#d4af37", fontSize: 28, margin: "0 0 8px 0" }}>
          Live Tournament Scores
        </h2>
        {liveScores.lastUpdated && (
          <div style={{ fontSize: 12, color: "rgba(245,240,225,0.35)" }}>
            Round {liveScores.round || "?"} • Updated {new Date(liveScores.lastUpdated).toLocaleTimeString()}
          </div>
        )}
      </div>

      <div style={{
        background: "rgba(0,0,0,0.25)",
        border: "1px solid rgba(212,175,55,0.15)",
        borderRadius: 8, overflow: "hidden"
      }}>
        <div style={{
          display: "grid",
          gridTemplateColumns: "50px 1fr 70px 80px 100px",
          padding: "12px 16px",
          background: "rgba(212,175,55,0.08)",
          borderBottom: "1px solid rgba(212,175,55,0.15)",
          fontSize: 11, letterSpacing: 2, textTransform: "uppercase",
          color: "rgba(245,240,225,0.5)"
        }}>
          <div>Pos</div><div>Player</div><div>Score</div><div>Thru</div><div style={{ textAlign: "right" }}>Earnings</div>
        </div>

        {sortedPlayers.map(([name, data], i) => (
          <div key={name} style={{
            display: "grid",
            gridTemplateColumns: "50px 1fr 70px 80px 100px",
            padding: "10px 16px",
            borderBottom: "1px solid rgba(255,255,255,0.03)",
            background: i < 3 ? "rgba(212,175,55,0.04)" : "transparent",
            fontSize: 14
          }}>
            <div style={{ fontWeight: 600, color: i < 3 ? "#d4af37" : "rgba(245,240,225,0.5)" }}>
              {data.position || "-"}
            </div>
            <div style={{ fontWeight: 500 }}>{name}</div>
            <div style={{ color: data.score < 0 ? "#4ceb4c" : data.score > 0 ? "#ff5555" : "#fff" }}>
              {data.score === 0 ? "E" : data.score > 0 ? `+${data.score}` : data.score}
            </div>
            <div style={{ color: "rgba(245,240,225,0.4)" }}>{data.thru || "-"}</div>
            <div style={{ textAlign: "right", color: "#d4af37", fontWeight: 600 }}>
              {formatMoney(data.earnings)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// RULES PAGE
// ============================================================
function RulesPage() {
  return (
    <div style={{ maxWidth: 700, margin: "0 auto", padding: "40px 20px" }}>
      <h2 style={{ color: "#d4af37", fontSize: 28, textAlign: "center", marginBottom: 32 }}>
        Pool Rules
      </h2>

      <div style={{
        background: "rgba(0,0,0,0.25)",
        border: "1px solid rgba(212,175,55,0.15)",
        borderRadius: 8, padding: 32
      }}>
        <Section title="How It Works">
          Pick one player from each of the 5 tiers (5 players total). At the conclusion of the tournament,
          your team will be ranked based on adding all the prize money your players earned at The Masters collectively.
          All players on your team are included in the earnings calculation.
        </Section>

        <Section title="Scoring">
          Total prize money earned. If your player wins The Masters, you get their full winner's share ($3,600,000).
          If they miss the cut, they earn $0. Simple as that.
        </Section>

        <Section title="Example">
          <div style={{
            background: "rgba(0,0,0,0.2)", borderRadius: 6, padding: 16, marginTop: 8,
            border: "1px solid rgba(255,255,255,0.05)"
          }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ borderBottom: "1px solid rgba(212,175,55,0.2)" }}>
                  <th style={thStyle}>Tier</th><th style={thStyle}>Player</th>
                  <th style={thStyle}>Finish</th><th style={{ ...thStyle, textAlign: "right" }}>Prize</th>
                </tr>
              </thead>
              <tbody>
                {[
                  [1, "Scottie Scheffler", "2nd", "$2,160,000"],
                  [2, "Collin Morikawa", "T-12", "$460,000"],
                  [3, "Jordan Spieth", "MC", "$0"],
                  [4, "Sepp Straka", "8th", "$620,000"],
                  [5, "Tiger Woods", "T-35", "$75,000"],
                ].map(([t, name, fin, prize], i) => (
                  <tr key={i} style={{ borderBottom: "1px solid rgba(255,255,255,0.03)" }}>
                    <td style={tdStyle}>{t}</td><td style={tdStyle}>{name}</td>
                    <td style={tdStyle}>{fin}</td>
                    <td style={{ ...tdStyle, textAlign: "right", color: "#d4af37" }}>{prize}</td>
                  </tr>
                ))}
                <tr>
                  <td colSpan={3} style={{ ...tdStyle, fontWeight: 700, textAlign: "right", paddingRight: 12 }}>TOTAL</td>
                  <td style={{ ...tdStyle, textAlign: "right", fontWeight: 700, color: "#d4af37", fontSize: 16 }}>$3,315,000</td>
                </tr>
              </tbody>
            </table>
          </div>
        </Section>

        <Section title="Buy-In & Payouts">
          Tournament buy-in is $20. Must submit your team and payment before first group tee-off on
          Thursday, April 9th, 2026.
        </Section>

        <div style={{
          background: "rgba(212,175,55,0.08)", borderRadius: 6, padding: 16, marginTop: 16,
          border: "1px solid rgba(212,175,55,0.2)", textAlign: "center"
        }}>
          <div style={{ fontWeight: 700, marginBottom: 8, color: "#d4af37" }}>Payout Structure</div>
          <div style={{ fontSize: 15 }}>
            1st Place: <strong>60%</strong> &nbsp;|&nbsp; 2nd Place: <strong>30%</strong> &nbsp;|&nbsp; 3rd Place: <strong>10%</strong>
          </div>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div style={{ marginBottom: 24 }}>
      <h3 style={{ color: "#d4af37", fontSize: 16, margin: "0 0 8px 0", letterSpacing: 1 }}>{title}</h3>
      <div style={{ color: "rgba(245,240,225,0.7)", fontSize: 14, lineHeight: 1.7 }}>{children}</div>
    </div>
  );
}

// ============================================================
// ADMIN PAGE
// ============================================================
function AdminPage({ isAdmin, setIsAdmin, entries, saveEntries, picksLocked, setPicksLocked, liveScores, setLiveScores, participants, saveParticipants }) {
  const [pw, setPw] = useState("");
  const [pwError, setPwError] = useState("");
  const [adminName, setAdminName] = useState("");
  const [adminPicks, setAdminPicks] = useState({});
  const [adminMsg, setAdminMsg] = useState("");
  const [newParticipantName, setNewParticipantName] = useState("");
  const [activeTab, setActiveTab] = useState("tracker"); // tracker, addpicks, entries

  const handleLogin = () => {
    if (pw === ADMIN_PASSWORD) {
      setIsAdmin(true);
      setPwError("");
    } else {
      setPwError("Incorrect password");
    }
  };

  const handleAdminSubmit = async () => {
    if (!adminName.trim()) { setAdminMsg("Enter a name"); return; }
    for (let t = 1; t <= 5; t++) {
      if (!adminPicks[t]) { setAdminMsg(`Pick Tier ${t}`); return; }
    }

    const entry = {
      id: generateId(),
      name: adminName.trim(),
      email: "",
      picks: [adminPicks[1], adminPicks[2], adminPicks[3], adminPicks[4], adminPicks[5]],
      tierPicks: { ...adminPicks },
      submittedAt: new Date().toISOString(),
      submittedBy: "admin"
    };

    await saveEntries([...entries, entry]);
    setAdminMsg(`Added ${adminName.trim()}'s entry`);
    setAdminName("");
    setAdminPicks({});
  };

  const handleDeleteEntry = async (id) => {
    const newEntries = entries.filter(e => e.id !== id);
    await saveEntries(newEntries);
    setAdminMsg("Entry deleted");
  };

  const handleRefreshScores = async () => {
    setAdminMsg("Fetching live scores...");
    const live = await fetchLiveScores();
    if (live) {
      setLiveScores(live);
      await storage.set(STORAGE_KEYS.SCORES, live);
      setAdminMsg(`Scores updated (${Object.keys(live.players).length} players)`);
    } else {
      setAdminMsg("⚠️ No Masters data found (tournament may not be active)");
    }
  };

  // Participant tracker helpers
  const addParticipant = async () => {
    if (!newParticipantName.trim()) return;
    const existing = participants.find(p => p.name.toLowerCase() === newParticipantName.trim().toLowerCase());
    if (existing) { setAdminMsg("Participant already exists"); return; }
    const p = {
      id: generateId(),
      name: newParticipantName.trim(),
      invited: true,
      paid: false,
      addedAt: new Date().toISOString()
    };
    await saveParticipants([...participants, p]);
    setNewParticipantName("");
    setAdminMsg(`Added ${p.name}`);
  };

  const togglePaid = async (id) => {
    const updated = participants.map(p => p.id === id ? { ...p, paid: !p.paid } : p);
    await saveParticipants(updated);
  };

  const removeParticipant = async (id) => {
    await saveParticipants(participants.filter(p => p.id !== id));
  };

  // Derive status for each participant
  const participantStatuses = participants.map(p => {
    const hasEntry = entries.some(e => e.name.toLowerCase().trim() === p.name.toLowerCase().trim());
    return { ...p, hasSubmitted: hasEntry };
  });

  const invitedCount = participants.length;
  const submittedCount = participantStatuses.filter(p => p.hasSubmitted).length;
  const paidCount = participants.filter(p => p.paid).length;
  const notSubmitted = participantStatuses.filter(p => !p.hasSubmitted);
  const notPaid = participantStatuses.filter(p => !p.paid);

  if (!isAdmin) {
    return (
      <div style={{ maxWidth: 400, margin: "0 auto", padding: "80px 20px", textAlign: "center" }}>
        <h2 style={{ color: "#d4af37", fontSize: 24, marginBottom: 20 }}>Admin Login</h2>
        <input
          type="password"
          value={pw}
          onChange={e => setPw(e.target.value)}
          onKeyDown={e => e.key === "Enter" && handleLogin()}
          placeholder="Enter admin password"
          style={{ ...inputStyle, textAlign: "center", maxWidth: 280, margin: "0 auto" }}
        />
        {pwError && <div style={{ color: "#ff9999", fontSize: 13, marginTop: 8 }}>{pwError}</div>}
        <div style={{ marginTop: 16 }}>
          <button onClick={handleLogin} style={goldBtnStyle}>Login</button>
        </div>
      </div>
    );
  }

  const tabStyle = (active) => ({
    background: active ? "rgba(212,175,55,0.15)" : "transparent",
    border: "none",
    borderBottom: active ? "2px solid #d4af37" : "2px solid transparent",
    color: active ? "#d4af37" : "rgba(245,240,225,0.5)",
    padding: "10px 20px",
    fontSize: 13,
    fontFamily: "'Georgia', serif",
    letterSpacing: 1.5,
    textTransform: "uppercase",
    cursor: "pointer",
  });

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "32px 16px" }}>
      <h2 style={{ color: "#d4af37", fontSize: 28, textAlign: "center", marginBottom: 24 }}>
        Admin Dashboard
      </h2>

      {adminMsg && (
        <div style={{
          background: "rgba(212,175,55,0.1)", border: "1px solid rgba(212,175,55,0.3)",
          borderRadius: 6, padding: "10px 16px", marginBottom: 16,
          textAlign: "center", fontSize: 14, color: "#d4af37"
        }}>
          {adminMsg}
        </div>
      )}

      {/* Quick Actions */}
      <div style={{
        display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
        gap: 12, marginBottom: 24
      }}>
        <AdminCard
          title="Picks Status"
          value={picksLocked ? "Locked" : "Open"}
          action={
            <button
              onClick={() => setPicksLocked(!picksLocked)}
              style={{ ...smallBtnStyle, background: picksLocked ? "rgba(100,200,100,0.15)" : "rgba(200,100,100,0.15)" }}
            >
              {picksLocked ? "Unlock Picks" : "Lock Picks"}
            </button>
          }
        />
        <AdminCard title="Invited" value={invitedCount} action={<div style={{ fontSize: 11, color: "rgba(245,240,225,0.4)" }}>people in the pool</div>} />
        <AdminCard title="Submitted" value={`${submittedCount}/${invitedCount}`} action={
          <div style={{ fontSize: 11, color: notSubmitted.length > 0 ? "#ffb732" : "#4ceb4c" }}>
            {notSubmitted.length > 0 ? `${notSubmitted.length} still need picks` : "All done!"}
          </div>
        } />
        <AdminCard title="Paid" value={`${paidCount}/${invitedCount}`} action={
          <div style={{ fontSize: 11, color: notPaid.length > 0 ? "#ffb732" : "#4ceb4c" }}>
            {notPaid.length > 0 ? `${notPaid.length} unpaid` : "All paid!"}
            {paidCount > 0 && <div style={{ color: "#d4af37", marginTop: 2 }}>Pool: {formatMoney(paidCount * BUY_IN)}</div>}
          </div>
        } />
        <AdminCard
          title="Live Scores"
          value={liveScores?.players ? `${Object.keys(liveScores.players).length}` : "—"}
          action={<button onClick={handleRefreshScores} style={smallBtnStyle}>Refresh</button>}
        />
      </div>

      {/* Tabs */}
      <div style={{
        display: "flex", gap: 0, marginBottom: 0,
        borderBottom: "1px solid rgba(255,255,255,0.06)"
      }}>
        <button onClick={() => setActiveTab("tracker")} style={tabStyle(activeTab === "tracker")}>
          Participant Tracker
        </button>
        <button onClick={() => setActiveTab("addpicks")} style={tabStyle(activeTab === "addpicks")}>
          Add Picks
        </button>
        <button onClick={() => setActiveTab("entries")} style={tabStyle(activeTab === "entries")}>
          All Entries ({entries.length})
        </button>
      </div>

      {/* ===== TAB: PARTICIPANT TRACKER ===== */}
      {activeTab === "tracker" && (
        <div style={{
          background: "rgba(0,0,0,0.25)", border: "1px solid rgba(212,175,55,0.15)",
          borderTop: "none", borderRadius: "0 0 8px 8px", padding: 24
        }}>
          {/* Add participant */}
          <div style={{ display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
            <input
              value={newParticipantName}
              onChange={e => setNewParticipantName(e.target.value)}
              onKeyDown={e => e.key === "Enter" && addParticipant()}
              placeholder="Add person to invite list..."
              style={{ ...inputStyle, flex: "1 1 200px", marginBottom: 0 }}
            />
            <button onClick={addParticipant} style={{ ...goldBtnStyle, padding: "10px 24px", fontSize: 13 }}>
              + Add
            </button>
          </div>

          {/* Legend */}
          <div style={{
            display: "flex", gap: 16, marginBottom: 16, flexWrap: "wrap",
            fontSize: 11, color: "rgba(245,240,225,0.4)", letterSpacing: 1
          }}>
            <span><span style={{color:"#4ceb4c", fontWeight: 700}}>●</span> Done &nbsp;&nbsp; <span style={{color:"#ffb732", fontWeight: 700}}>●</span> Pending &nbsp;&nbsp; <span style={{color:"#ff5555", fontWeight: 700}}>●</span> Missing</span>
          </div>

          {/* Table header */}
          {participants.length > 0 && (
            <div style={{
              display: "grid",
              gridTemplateColumns: "1fr 90px 90px 60px",
              padding: "8px 12px",
              background: "rgba(212,175,55,0.06)",
              borderRadius: "6px 6px 0 0",
              fontSize: 10, letterSpacing: 2, textTransform: "uppercase",
              color: "rgba(245,240,225,0.4)"
            }}>
              <div>Name</div><div style={{ textAlign: "center" }}>Picks</div><div style={{ textAlign: "center" }}>Paid</div><div></div>
            </div>
          )}

          {/* Participant rows */}
          {participantStatuses.map((p, i) => (
            <div key={p.id} style={{
              display: "grid",
              gridTemplateColumns: "1fr 90px 90px 60px",
              padding: "10px 12px",
              alignItems: "center",
              borderBottom: "1px solid rgba(255,255,255,0.04)",
              background: i % 2 === 0 ? "transparent" : "rgba(0,0,0,0.1)"
            }}>
              <div style={{ fontWeight: 500, fontSize: 14 }}>{p.name}</div>

              {/* Picks status */}
              <div style={{ textAlign: "center" }}>
                {p.hasSubmitted ? (
                  <span style={{ color: "#4ceb4c", fontSize: 13, fontWeight: 600 }}>Done</span>
                ) : (
                  <span style={{ color: "#ffb732", fontSize: 13, fontWeight: 600 }}>Pending</span>
                )}
              </div>

              {/* Paid toggle */}
              <div style={{ textAlign: "center" }}>
                <button
                  onClick={() => togglePaid(p.id)}
                  style={{
                    background: p.paid ? "rgba(76,235,76,0.12)" : "rgba(255,85,85,0.1)",
                    border: `1px solid ${p.paid ? "rgba(76,235,76,0.35)" : "rgba(255,85,85,0.3)"}`,
                    borderRadius: 4,
                    padding: "3px 12px",
                    fontSize: 12,
                    color: p.paid ? "#4ceb4c" : "#ff5555",
                    fontWeight: 600,
                    cursor: "pointer",
                    fontFamily: "'Georgia', serif",
                    minWidth: 60
                  }}
                >
                  {p.paid ? "Paid" : "Unpaid"}
                </button>
              </div>

              {/* Remove */}
              <div style={{ textAlign: "center" }}>
                <button
                  onClick={() => { if (confirm(`Remove ${p.name}?`)) removeParticipant(p.id); }}
                  style={{
                    background: "none", border: "none",
                    color: "rgba(245,240,225,0.25)", cursor: "pointer",
                    fontSize: 14, padding: 4
                  }}
                  title="Remove"
                >
                  ✕
                </button>
              </div>
            </div>
          ))}

          {participants.length === 0 && (
            <div style={{ textAlign: "center", padding: 32, color: "rgba(245,240,225,0.3)", fontSize: 14 }}>
              No participants yet. Add people you've invited above.
            </div>
          )}

          {/* Summary bar */}
          {participants.length > 0 && (
            <div style={{
              marginTop: 16, padding: 16,
              background: "rgba(212,175,55,0.06)",
              border: "1px solid rgba(212,175,55,0.15)",
              borderRadius: 6,
              display: "flex", justifyContent: "space-around", flexWrap: "wrap", gap: 12,
              fontSize: 13
            }}>
              <div>
                <strong style={{ color: "#d4af37" }}>{invitedCount}</strong>{" "}
                <span style={{ color: "rgba(245,240,225,0.5)" }}>Invited</span>
              </div>
              <div>
                <strong style={{ color: submittedCount === invitedCount ? "#4ceb4c" : "#ffb732" }}>{submittedCount}</strong>{" "}
                <span style={{ color: "rgba(245,240,225,0.5)" }}>Submitted</span>
              </div>
              <div>
                <strong style={{ color: paidCount === invitedCount ? "#4ceb4c" : "#ffb732" }}>{paidCount}</strong>{" "}
                <span style={{ color: "rgba(245,240,225,0.5)" }}>Paid</span>
              </div>
              <div>
                <strong style={{ color: "#d4af37" }}>{formatMoney(paidCount * BUY_IN)}</strong>{" "}
                <span style={{ color: "rgba(245,240,225,0.5)" }}>Collected</span>
              </div>
            </div>
          )}

          {/* Nudge lists */}
          {notSubmitted.length > 0 && (
            <div style={{ marginTop: 16, fontSize: 13, color: "rgba(245,240,225,0.5)" }}>
              <strong style={{ color: "#ffb732" }}>Still need picks:</strong>{" "}
              {notSubmitted.map(p => p.name).join(", ")}
            </div>
          )}
          {notPaid.length > 0 && (
            <div style={{ marginTop: 8, fontSize: 13, color: "rgba(245,240,225,0.5)" }}>
              <strong style={{ color: "#ff5555" }}>Still need payment:</strong>{" "}
              {notPaid.map(p => p.name).join(", ")}
            </div>
          )}
        </div>
      )}

      {/* ===== TAB: ADD PICKS ===== */}
      {activeTab === "addpicks" && (
        <div style={{
          background: "rgba(0,0,0,0.25)", border: "1px solid rgba(212,175,55,0.15)",
          borderTop: "none", borderRadius: "0 0 8px 8px", padding: 24
        }}>
          <h3 style={{ color: "#d4af37", fontSize: 16, margin: "0 0 16px 0" }}>
            Submit Picks on Someone's Behalf
          </h3>
          <input
            value={adminName}
            onChange={e => setAdminName(e.target.value)}
            placeholder="Person's name"
            style={{ ...inputStyle, maxWidth: 300 }}
          />
          {[1,2,3,4,5].map(tier => (
            <div key={tier} style={{ marginTop: 12 }}>
              <label style={{ ...labelStyle, fontSize: 12 }}>{TIERS[tier].label}</label>
              <select
                value={adminPicks[tier] || ""}
                onChange={e => setAdminPicks(prev => ({ ...prev, [tier]: e.target.value }))}
                style={{ ...inputStyle, maxWidth: 300 }}
              >
                <option value="">Select player...</option>
                {TIERS[tier].players.filter(p => p !== "Anyone else not listed").map(p => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>
          ))}
          <button onClick={handleAdminSubmit} style={{ ...goldBtnStyle, marginTop: 16 }}>
            Add Entry
          </button>
        </div>
      )}

      {/* ===== TAB: ALL ENTRIES ===== */}
      {activeTab === "entries" && (
        <div style={{
          background: "rgba(0,0,0,0.25)", border: "1px solid rgba(212,175,55,0.15)",
          borderTop: "none", borderRadius: "0 0 8px 8px", padding: 24
        }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 8 }}>
            <h3 style={{ color: "#d4af37", fontSize: 16, margin: 0 }}>
              All Entries ({entries.length})
            </h3>
            {entries.length > 0 && (
              <button
                onClick={() => {
                  if (confirm(`Are you sure you want to delete ALL ${entries.length} entries? This cannot be undone.`)) {
                    saveEntries([]);
                    setAdminMsg("All entries cleared");
                  }
                }}
                style={{
                  background: "rgba(200,50,50,0.12)",
                  border: "1px solid rgba(200,50,50,0.35)",
                  color: "#ff5555",
                  borderRadius: 4, padding: "6px 16px",
                  fontSize: 12, cursor: "pointer",
                  fontFamily: "'Georgia', serif",
                  letterSpacing: 0.5
                }}
              >
                Clear All Entries
              </button>
            )}
          </div>
          {entries.length === 0 && (
            <div style={{ color: "rgba(245,240,225,0.4)", textAlign: "center", padding: 20 }}>
              No entries yet
            </div>
          )}
          {entries.map(entry => (
            <div key={entry.id} style={{
              display: "flex", justifyContent: "space-between", alignItems: "center",
              padding: "12px 16px",
              marginBottom: 6,
              borderRadius: 6,
              background: "rgba(0,0,0,0.15)",
              border: "1px solid rgba(255,255,255,0.04)",
              flexWrap: "wrap", gap: 8
            }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 600 }}>
                  {entry.name}
                  {entry.submittedBy === "admin" && (
                    <span style={{ fontSize: 10, color: "rgba(212,175,55,0.5)", marginLeft: 8 }}>
                      (added by admin)
                    </span>
                  )}
                </div>
                <div style={{ fontSize: 12, color: "rgba(245,240,225,0.35)", marginTop: 2 }}>
                  {entry.picks.join(" · ")}
                </div>
                <div style={{ fontSize: 11, color: "rgba(245,240,225,0.2)", marginTop: 2 }}>
                  Submitted {new Date(entry.submittedAt).toLocaleString()}
                </div>
              </div>
              <button
                onClick={() => {
                  if (confirm(`Delete ${entry.name}'s entry? This cannot be undone.`)) handleDeleteEntry(entry.id);
                }}
                style={{
                  background: "rgba(200,50,50,0.15)",
                  border: "1px solid rgba(200,50,50,0.4)",
                  color: "#ff5555",
                  borderRadius: 4, padding: "6px 16px",
                  fontSize: 12, cursor: "pointer",
                  fontFamily: "'Georgia', serif",
                  fontWeight: 600,
                  letterSpacing: 0.5
                }}
              >
                Delete Entry
              </button>
            </div>
          ))}
        </div>
      )}

      <div style={{ textAlign: "center", marginTop: 24 }}>
        <button onClick={() => setIsAdmin(false)} style={{ ...smallBtnStyle, color: "rgba(245,240,225,0.4)" }}>
          Logout
        </button>
      </div>
    </div>
  );
}

function AdminCard({ title, value, action }) {
  return (
    <div style={{
      background: "rgba(0,0,0,0.25)",
      border: "1px solid rgba(212,175,55,0.15)",
      borderRadius: 8, padding: 20, textAlign: "center"
    }}>
      <div style={{ fontSize: 11, letterSpacing: 2, textTransform: "uppercase", color: "rgba(245,240,225,0.4)", marginBottom: 6 }}>
        {title}
      </div>
      <div style={{ fontSize: 22, fontWeight: 700, color: "#f5f0e1", marginBottom: 10 }}>{value}</div>
      {action}
    </div>
  );
}

// ============================================================
// SHARED STYLES
// ============================================================
const goldBtnStyle = {
  background: "linear-gradient(135deg, #d4af37 0%, #b8941f 100%)",
  color: "#0a2e0a",
  border: "none",
  borderRadius: 6,
  padding: "12px 32px",
  fontSize: 14,
  fontWeight: 700,
  letterSpacing: 2,
  textTransform: "uppercase",
  cursor: "pointer",
  fontFamily: "'Georgia', serif",
};

const smallBtnStyle = {
  background: "rgba(212,175,55,0.1)",
  border: "1px solid rgba(212,175,55,0.25)",
  color: "#d4af37",
  borderRadius: 4,
  padding: "6px 16px",
  fontSize: 12,
  cursor: "pointer",
  fontFamily: "'Georgia', serif",
};

const inputStyle = {
  width: "100%",
  background: "rgba(0,0,0,0.3)",
  border: "1px solid rgba(255,255,255,0.1)",
  borderRadius: 6,
  padding: "10px 14px",
  color: "#f5f0e1",
  fontSize: 14,
  fontFamily: "'Georgia', serif",
  outline: "none",
  boxSizing: "border-box",
  marginBottom: 8,
};

const labelStyle = {
  display: "block",
  fontSize: 11,
  letterSpacing: 2,
  textTransform: "uppercase",
  color: "rgba(245,240,225,0.4)",
  marginBottom: 6,
};

const playerBtnStyle = {
  border: "1px solid rgba(255,255,255,0.08)",
  borderRadius: 6,
  padding: "8px 14px",
  fontSize: 13,
  cursor: "pointer",
  fontFamily: "'Georgia', serif",
  transition: "all 0.15s",
};

const thStyle = {
  textAlign: "left",
  padding: "8px 8px",
  fontSize: 11,
  letterSpacing: 1,
  textTransform: "uppercase",
  color: "rgba(245,240,225,0.4)",
};

const tdStyle = {
  padding: "8px 8px",
  fontSize: 13,
  color: "rgba(245,240,225,0.75)",
};
